print(":-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:\n::                                                                                                                                                               ::\n::                                                             🙏  WELCOME TO SMART CITY  🙏                                                                     ::\n::                                                                DIGITAL CITIZEN PORTAL                                                                         ::\n::                                                                                                                                                               ::\n:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:")
print()
def start_decor():
  print("===================================================================================================================================================================")
  print("                                                                        📃 MAIN MENU 📃")
  print("===================================================================================================================================================================")
  print()
  print("1.💻 CITIZEN LOGIN  \n2.🆕 NEW CITIZEN REGISTRATION  \n3.🔎 EXPLORE SERVICES  \n4.🚨 HELP \n5.❌ EXIT ")
  print()
  print("===================================================================================================================================================================")
start_decor()
details_id=["236w1a4301","236w1a4302","236w1a4303"]
details_city=["malkipuram","narsipatnam","palakollu"]
details_name=["Bhavani","meghana","sailaja"]
details_age=[20,20,20]
details_email=["bhavani@gmail.com","meghana@gmail.com","sailaja@gmail.com"]
details_phn=["7842546869","7995074506","7416193899"]
details_pass=["bhavani24","meghana02","sailu03"]
details_notifications=[[],[],[]]
details_appointments=[[],[],[]]
details_applications=[[],[],[]]
details_history=[[],[],[]]
details_bills=[[[],[]],[[],[]],[[],[]]]
applications={}
# registration beginning----------------------------------------
def citizen_reg():
  global citizen_id_index
  citizen_id_v=""
  citizen_city_v=""
  citizen_name_v=""
  citizen_age_v=" "
  citizen_email_v=""
  citizen_phn_v=""
  citizen_pass_v=""
  print("===================================================================================================================================================================")
  print("                                                                 🆕 NEW CITIZEN REGISTRATION 🆕")
  print("===================================================================================================================================================================")
  print()
  def citizen_id():
    nonlocal citizen_id_v
    citizen_id_v=input("🪪  ENTER YOUR CITIZEN ID: ")
    print()
    citizen_id_v=citizen_id_v.lower()
    if not citizen_id_v.startswith("236w1a") or len(citizen_id_v)!=10:
      print("❗ CAUTION : 'YOUR CITIZEN ID MUST STARTS WITH '236w1a' AND THE ID LENGTH MUST BE 10'❗")
      print()
      citizen_id()
    elif citizen_id_v in details_id:
      print("❗ THE CITIZEN ID ALREADY EXIST. TRY TO LOGIN ❗")
      print()
      inp_citizen_id=input("1.OK✅ \n2.NO❌ \nENTER YOUR OPTION HERE(1-2): ")
      print()
      if inp_citizen_id=="1":
        citizen_login()
      elif inp_citizen_id=="2":
        citizen_reg()
      else:
        print("\n ‼️ INVALID OPTION TRY AGAIN ‼️\n")
        print()
  citizen_id()
  def citizen_city():
    nonlocal citizen_city_v
    citizen_city_v=input("🏙️  ENTER YOUR CITY: ")
    print()
    if citizen_city_v.isalpha()!=True or len(citizen_city_v)<3:
      print("❗ INVALID CITY. THE NAME MUST CONTAINS ONLY ALPHABETS AND LENGTH MUST BE ATLEAST 3  ❗")
      print()
      citizen_city()
  citizen_city()
  def citizen_name():
    nonlocal citizen_name_v
    citizen_name_v=input("🔠  ENTER YOUR NAME: ")
    print()
    if citizen_name_v.isalpha()!=True:
      print("❗ INVALID NAME. THE NAME MUST CONTAINS ONLY ALPHABETS. ❗")
      print()
      citizen_name()
  citizen_name()
  def citizen_age():
    nonlocal citizen_age_v
    citizen_age_v=input("⬜  ENTER YOUR AGE: ")
    print()
    if citizen_age_v.isdigit()==False or int(citizen_age_v)<18:
      print("❗ INVALID AGE. THE AGE MUST CONTAINS ONLY NUMBERS. AND AGE MUST BE GREATER THAN 18 ❗")
      print()
      citizen_age()
  citizen_age()
  def citizen_email():
    nonlocal citizen_email_v
    citizen_email_v=input("📧  ENTER YOUR EMAIL: ")
    print()
    if citizen_email_v.endswith("@gmail.com")==False and citizen_email_v.endswith("@email.com")==False or citizen_email_v=="" or len(citizen_email_v)<=10:
      print("❗ INVALID!  EMAIL MUST ENDS WITH @GMAIL.COM OR @EMAIL.COM AND LENGTH MUST BE ATLEAT 11❗")
      print()
      citizen_email()
  citizen_email()
  def citizen_phn():
    nonlocal citizen_phn_v
    citizen_phn_v=input("☎️  ENTER YOUR MOBILE NUMBER: ")
    print()
    if citizen_phn_v.isdigit()!=True or len(citizen_phn_v)!=10:
      print("❗ INVALID! MOBILE NUMBER ONLY CONTAINS 10 NUMBERS ❗")
      print()
      citizen_phn()
  citizen_phn()
  def citizen_pass():
    nonlocal citizen_pass_v
    citizen_pass_v=input("🔐  CREATE YOUR PASSWORD: ")
    print()
    if len(citizen_pass_v)<8:
      print("❗THE PASSWORD HAS TO CONTAIN ATLEAST 8 CHARACTERS❗")
      print()
      citizen_pass()
  citizen_pass()
  print("===================================================================================================================================================================")
  print("                                               ✅ REGISTRATION SUCCESSFULLY COMPLETED. CHECK YOUR DETAILS HERE✅")
  print("===================================================================================================================================================================")
  print("\nCITIZEN ID:",citizen_id_v)
  print("\nCITIZEN CITY:",citizen_city_v)
  print("\nCITIZEN NAME:",citizen_name_v)
  print("\nCITIZEN AGE:",citizen_age_v)
  print("\nCITIZEN EMAIL:",citizen_email_v)
  print("\nCITIZEN PHONE NUMBER:",citizen_phn_v)
  print("==================================================================================================================================================================")
  print()
  details_id.append(citizen_id_v)
  details_city.append(citizen_city_v)
  details_name.append(citizen_name_v)
  details_age.append(citizen_age_v)
  details_email.append(citizen_email_v)
  details_phn.append(citizen_phn_v)
  details_pass.append(citizen_pass_v)
  details_notifications.append(["● YOU HAVE REGISTERED.",])
  details_appointments.append([])
  details_applications.append([])
  details_history.append(["● NEW CITIZEN REGISTRATION",])
  details_bills.append([[],[]])
  print("PLEASE LOG IN HERE: ")
  print()
  citizen_login()
#registration conclusion--------------------------------------
#citizen dashboard beginning------------------------------------
def citizen_dashboard():
  print("===================================================================================================================================================================")
  print("                                                                    🌐  CITIZEN DASHBOARD 🌐")
  print("===================================================================================================================================================================")
  print()
  print("CHOOSE YOUR OPTION \n1.🌐  MY DASHBOARD \n2.🏢  GOVERNMENT SERVICES \n3.📄  MY APPLICATIONS \n4.💲  BILLS & FINES \n5.📅  APPOINTMENTS \n6.🔔  NOTIFICATIONS \n7.🔁  ACTIVITY SUMMARY \n8.🔚  LOG OUT              ")
  print()
  inp_citizen_dashboard=input("⌨️ ENTER YOUR OPTION HERE(1-8): ")
  print()
  details_history[citizen_id_index].append("● CITIZEN DASHBOARD")
  if inp_citizen_dashboard.isdigit()==True:
    match inp_citizen_dashboard:
      case "1":
        def my_dashboard():
          print("===================================================================================================================================================================")
          print("                                                                   🌐 MY DASHBOARD 🌐")
          print("===================================================================================================================================================================")
          print()
          print("\nYOUR DETAILS ARE:")
          print("🪪  CITIZEN ID: ",details_id[citizen_id_index])
          print("🏙️  CITIZEN CITY: ",details_city[citizen_id_index])
          print("🔠  CITIZEN NAME: ",details_name[citizen_id_index])
          print("⬜  CITIZEN AGE: ",details_age[citizen_id_index])
          print("📧  CITIZEN EMAIL: ",details_email[citizen_id_index])
          print("☎️  CITIZEN PHONE NUMBER: ",details_phn[citizen_id_index])
          print("📄  MY APPLICATIONS: ",len(details_applications[citizen_id_index]))
          print("🔔  NOTIFICATIONS: ",len(details_notifications[citizen_id_index]))
          print("📅  APPOINTMENTS: ",len(details_appointments[citizen_id_index]))
          print("💵  TOTAL PAID BILLS: ",len(details_bills[citizen_id_index][1]))
          print("⌛  TOTAL PENDING BILLS: ",len(details_bills[citizen_id_index][0]))
          inp_my_dashboard=input("\n🔙  ENTER 1 TO GO BACK: ")
          print()
          details_history[citizen_id_index].append("● MY DASHBOARD")
          print()
          if inp_my_dashboard=="1":
            citizen_dashboard()
          else:
            print("‼️ INVALID OPTION TRY AGAIN ‼️")
            print()
            my_dashboard()
        my_dashboard()
      case "2":
        citizen_government_services()
        details_history[citizen_id_index].append("● GOVERNMENT SERVICES")
      case "3":
        if details_applications[citizen_id_index]:
          my_apps()
        else:
          def my_apps_var():
            my_apps_v=input("⛔ THERE ARE NO APPLICATIONS HERE ⛔\n\n🔙 ENTER 1 TO GO BACK: ")
            print()
            if my_apps_v=="1":
              citizen_dashboard()
            else:
              print("‼️ INVALID OPTION TRY AGAIN ‼️")
              print()
              my_apps_var()
          my_apps_var()
      case "4":
        bills()
      case "5":
          appointments()
      case "6":
        def notifications():
          print("=====================================================================================================================================================================")
          print("                                                                       🔔 NOTIFICATIONS 🔔")
          print("=====================================================================================================================================================================")
          details_history[citizen_id_index].append("● NOTIFICATIONS")
          for x in details_notifications[citizen_id_index]:
            print(x)
          print()
          notifications_v=input("🔙  ENTER 1 TO GO BACK: ")
          print()
          if notifications_v=="1":
            citizen_dashboard()
          else:
            print("‼️ INVALID OPTION TRY AGAIN‼️")
            print()
            notifications()
        notifications()
      case "7":
        print("=====================================================================================================================================================================")
        print("                                                                        🔁 ACTIVITY SUMMARY🔁")
        print("=====================================================================================================================================================================")
        def activity():
          for x in details_history[citizen_id_index]:
            print(x)
          print()
          details_history.append[citizen_id_index]("● ACTIVITY SUMMMARY")
          activity_inp=input("🔙  ENTER 1 TO GO BACK: ")
          print()
          if activity_inp=="1":
            citizen_dashboard()
          else:
            print("‼️ INVALID OPTION TRY AGAIN ‼️")
            print()
            activity()
        activity()
      case "8":
        def exit_2():
          exit_2_inp=input("DO YOU REALLY WANT TO LOGOUT? \n\n1.✅ YES \n2.❌ NO \n⌨️  TYPE YOUR OPTION HERE: ")
          print()
          if exit_2_inp=="1":
            print()
            print("LOGGING OUT.....")
            print()
            print(" 👋  YOU HAVE BEEN LOGGED OUT FROM SMART CITY  👋")
            print()
            start_decor()
            choose_opt()
          elif exit_2_inp=="2":
            citizen_dashboard()
          else:
            print("‼️INVALID OPTION TRY AGAIN‼️")
            print()
            exit_2()
        exit_2()
      case _:
        print("‼️ INVALID OPTION TRY AGAIN ‼️")
        print()
        citizen_dashboard()
  else:
    print("‼️ INVALID OPTION TRY AGAIN ‼️")
    print()
    citizen_dashboard()
#citizen dashboard conclusion-------------------------
#appointments beginning-------------------------------
def appointments():
  global avail_var
  print("=====================================================================================================================================================================")
  print("                                                                       📅  APPOINTMENTS  📅")
  print("=====================================================================================================================================================================")
  appoinment_inp=input("1.🏤  MUNCIPAL OFFICE \n2.🚙  TRANSPORT OFFICE \n3.⚡  ELECTRICITY DEPARTMENT \n4.💧  WATER DEPARTMENT \n5.🔙  BACK \n ⌨️  ENTER YOUR OPTION HERE(1-5): ")
  details_history[citizen_id_index].append("● APPOINTMENTS")
  if appoinment_inp.isdigit()==False:
    print("‼️ INVALID OPTION TRY AGAIN ‼️")
    print()
    appointments()
  else:
    match appoinment_inp:
      case "1":
        appointments_var="MUNCIPAL OFFICE"
        available_slots()
        str_appointment="● YOU HAVE BOOKED AN APPOINMENT "+"FOR "+appointments_var+" IN "+avail_var
        details_notifications[citizen_id_index].append(str_appointment)
      case "2":
        appointments_var="TRANSPORT OFFICE"
        available_slots()
        str_appointment="● YOU HAVE BOOKED AN APPOINMENT "+"FOR "+appointments_var+" IN "+avail_var
        details_notifications[citizen_id_index].append(str_appointment)
      case "3":
        appointments_var="ELECTRICITY DEPARTMENT"
        available_slots()
        str_appointment="● YOU HAVE BOOKED AN APPOINMENT "+"FOR "+appointments_var+" IN "+avail_var
        details_notifications[citizen_id_index].append(str_appointment)
      case "4":
        appointments_var="WATER DEPARTMENT"
        available_slots()
        str_appointment="● YOU HAVE BOOKED AN APPOINMENT "+"FOR "+appointments_var+" IN "+avail_var
        details_notifications[citizen_id_index].append(str_appointment)
      case "5":
        citizen_dashboard()
      case _:
        print("‼️ INVALID OPTION TRY AGAIN ‼️")
        print()
        appointments()
  appointment_inp_back=input("🔙  ENTER 1 TO GO BACK :")
  print()
  if appointment_inp_back=="1":
    citizen_dashboard()
  else:
    print("‼️ INVALID OPTION TRY AGAIN ‼️")
    print()
    appointments()
#appointments conclusion-------------------------------
#timings begining--------------------
def available_slots():
  global avail_var
  print("=====================================================================================================================================================================")
  print("                                                                       🏷️ AVAILABLE SLOTS 🏷️")
  print("=====================================================================================================================================================================")
  print()
  print("CHOOSE YOUR SLOT FOR THE APPOINTMENT:")
  print()
  available_inp=input("1.🕙  10:00 AM \n2.🕚  11:00 AM \n3.🕑  02:00 PM \n4.🕒  03:00 PM \n5.BACK \n ⌨️ ENTER YOUR OPTION HERE(1-5): ")
  print()
  if available_inp.isdigit()==False:
    print("‼️ INVALID OPTION TRY AGAIN ‼️")
    print()
    appointments()
  else:
    match available_inp:
      case "1":
        avail_var="10:00 AM"
        print("✅ APPOINTMENT APPROVED ✅")
        print()
      case "2":
        avail_var="11:00 AM"
        print("✅ APPOINTMENT APPROVED ✅")
        print()
      case "3":
        avail_var="02:00 PM"
        print("✅ APPOINTMENT APPROVED ✅")
        print()
      case "4":
        avail_var="03:00 PM"
        print("✅ APPOINTMENT APPROVED ✅")
        print()
      case "5":
        appointments()
      case _:
        print("‼️INVALID OPTION TRY AGAIN‼️")
        print()
        appointments()
#timings conclusion-----------------
#government services beginning-----------------------------------------
def citizen_government_services():
  print("=====================================================================================================================================================================")
  print("                                                                      🛎️  GOVERNMENT SERVICES  🛎️")
  print("=====================================================================================================================================================================")
  print()
  print("CHOOSE YOUR OPTION \n1.💳 NEW ID CARD \n2.🏡 ADDRESS CHANGE \n3.🚗 VEHICLE PERMITS \n4.📃 BIRTH CERTIFICATES \n5.🪪 BUSINESS LICENSE \n6.🗑️ WASTE MANAGEMENT REQUEST \n7.💧 WATER CONNECTION \n8.⚡ ELECTRICITY COMPLAINT \n9.🔍 SEARCH SERVICE \n10.🔙 BACK")
  print()
  inp_government_services=input("⌨️  ENTER YOUR OPTION HERE(1-10):")
  print()
  if inp_government_services.isdigit()==True:
    match inp_government_services:
      case "1":
        new_id_card()
        service_details()
      case "2":
        address_change()
        service_details()
      case "3":
        vehicle_permit()
        service_details()
      case "4":
        birth_certificate()
        service_details()
      case "5":
        business_license()
        service_details()
      case "6":
        waste_management_system()
        service_details()
      case "7":
        water_connection()
        service_details()
      case "8":
        electricity_complaint()
        service_details()
      case "9":
        search_service()
      case "10":
        # print("BACK")
        citizen_dashboard()
      case _:
        print("‼️ INVALID OPTION!  TRY AGAIN ‼️")
        citizen_government_services()
#government services comclusion-----------------------------------
#service details---------------------------------------------------
def service_details():
  print()
  print("=====================================================================================================================================================================")
  print("                                                                   📋 SERVICE DETAILS 📋")
  print("=====================================================================================================================================================================")
  global citizen_id_index,status
  print("SERVICE ID:",service_id)
  print("SERVICE NAME:",service_name)
  print("DEPARTMENT:",department)
  print("FEE:",fee)
  print("PROCESSING TIME:",processing_time)
  print("STATUS:",status)
  print()
  details_history[citizen_id_index].append("● SERVICE DETAILS")
  inp_new_id_card=input("1.🔙  BACK \n2.✔️  APPLY NOW \n⌨️   TYPE YOUR OPTION HERE(1-2): ")
  print()
  if inp_new_id_card=="1":
    citizen_government_services()
  elif inp_new_id_card=="2":
    global app_id
    apply_now()
    print("=====================================================================================================================================================================")
    print("                                                               📋 APPLICATION FORM 📋")
    print("=====================================================================================================================================================================")
    print("APPLICATION ID: ",app_id)
    print("SERVICEID:",service_id)
    print("SERVICE:",service_name)
    print("CITIZEN:",details_name[citizen_id_index])
    print("FEE:",fee)
    print("STATUS:",status)
    print()
    app_inp=input("DO YOU REALLY WANT TO PAY THE BILL NOW? \n\n1.YES✅ \n2.NO❌ \n ⌨️ TYPE YOUR OPTION HERE(1-2):")
    print()
    if app_inp=="1":
      print("✅ PAYMENT DONE. THANK YOU! TO TRACK YOUR APPLICATION STATUS VISIT MY APPLICATIONS✅")
      print()
      bill_v=[app_id,fee]
      details_bills[citizen_id_index][1].append(bill_v)
    elif app_inp=="2":
      print("😊 PAY THE BILL WHEN YOU ARE FREE IN BILLS SECTION 😊")
      print()
      apply_now()
      bill_v=[app_id,fee]
      details_bills[citizen_id_index][0].append(bill_v)
    else:
      print("‼️ INVALID OPTION TRY AGAIN ‼️")
      print()
      apply_now()
    details_applications[citizen_id_index].append(app_id)
    status="UNDER REVIEW"
    dict_application={"APPLICATION ID: ":app_id,
                      "SERVICEID:":service_id,
                      "SERVICE:":service_name,
                      "CITIZEN:":details_name[citizen_id_index],
                      "FEE:":fee,
                      "STATUS:":status}
    applications[app_id]=dict_application
    str_application="● YOU HAVE SUBMITTED AN APPLICATION WITH APPLICATION ID: "+app_id
    details_notifications[citizen_id_index].append(str_application)
    details_history[citizen_id_index].append("● APPLICATION FORM")
    inp_new_id_card_v=input("1.🔙  BACK \n2.💲  BILLS \n3.🏢  GOVERNMENT SERVICES \n4.📄  MY APPLICATIONS \n ⌨️ TYPE YOUR OPTION HERE(1-4): ")
    print()
    if inp_new_id_card_v=="1":
      service_details()
    elif inp_new_id_card_v=="2":
      bills()
    elif inp_new_id_card_v=="3":
      citizen_government_services()
    elif inp_new_id_card_v=="4":
      my_apps()
    else:
      print("‼️ INVALID OPTION TRY AGAIN ‼️")
      print()
      service_details()
  else:
    print("‼️ INVALID OPTION TRY AGAIN ‼️")
    print()
    service_details()
#service details----------------------------------------------
#service ids and all beginning------------------------------------
def new_id_card():
  print("=====================================================================================================================================================================")
  print("                                                                      💳  NEW ID CARD 💳")
  print("=====================================================================================================================================================================")
  global service_id,service_name,department,fee,processing_time,status
  service_id="NIC"+details_id[citizen_id_index]
  service_name="NEW ID CARD"
  department="MUNCIPAL OFFICE"
  fee=500
  processing_time="2 DAYS"
  status ="AVAILABLE"
  print()
def address_change():
  print("=====================================================================================================================================================================")
  print("                                                                     🏠 ADDRESS CHANGE🏠")
  print("=====================================================================================================================================================================")
  global service_id,service_name,department,fee,processing_time,status
  service_id="ADC"+details_id[citizen_id_index]
  service_name= "ADDRESS CHANGE"
  department="MUNCIPAL OFFICE"
  fee=200
  processing_time="1 DAY"
  status ="AVAILABLE"
  print()
def vehicle_permit():
  print("=====================================================================================================================================================================")
  print("                                                                     🚗 VEHICLE PERMIT 🚗")
  print("=====================================================================================================================================================================")
  global service_id,service_name,department,fee,processing_time,status
  service_id="VEP"+details_id[citizen_id_index]
  service_name= "VEHICLE PERMIT"
  department="TRANSPORT OFFICE"
  fee=1000
  processing_time="1 DAY"
  status ="AVAILABLE"
  print()
def birth_certificate():
  print("=====================================================================================================================================================================")
  print("                                                                    📄 BIRTH CERTIFICATE 📄")
  print("=====================================================================================================================================================================")
  global service_id,service_name,department,fee,processing_time,status
  service_id="BIC"+details_id[citizen_id_index]
  service_name= "BIRTH CERTIFICATE"
  department="MUNCIPAL OFFICE"
  fee=200
  processing_time="1 DAY"
  status ="AVAILABLE"
  print()
def business_license():
  print("=====================================================================================================================================================================")
  print("                                                                   💳 BUSINESS LICENSE 💳")
  print("=====================================================================================================================================================================")
  global service_id,service_name,department,fee,processing_time,status
  service_id="BUL"+details_id[citizen_id_index]
  service_name= "BUSINESS LICENSE"
  department="MUNCIPAL OFFICE"
  fee=500
  processing_time="3 DAY"
  status ="AVAILABLE"
  print()
def waste_management_system():
  print("=====================================================================================================================================================================")
  print("                                                                🚮 WASTE MANAGEMENT SYSTEM 🚮")
  print("=====================================================================================================================================================================")
  global service_id,service_name,department,fee,processing_time,status
  service_id="WMS"+details_id[citizen_id_index]
  service_name= "WASTE MANAGEMENT SYSTEM"
  department="MUNCIPAL OFFICE"
  fee=200
  processing_time="1 DAY"
  status ="AVAILABLE"
  print()
def water_connection():
  print("=====================================================================================================================================================================")
  print("                                                                    💧WATER CONNECTION💧 ")
  print("=====================================================================================================================================================================")
  global service_id,service_name,department,fee,processing_time,status
  service_id="WAC"+details_id[citizen_id_index]
  service_name= "WATER CONNECTION"
  department="WATER DEPARTMENT"
  fee=200
  processing_time="1 DAY"
  status ="AVAILABLE"
  print()
def electricity_complaint():
  print("=====================================================================================================================================================================")
  print("                                                                  ⚡ELECTRICITY COMPLAINT⚡")
  print("=====================================================================================================================================================================")
  global service_id,service_name,department,fee,processing_time,status
  service_id="ELC"+details_id[citizen_id_index]
  service_name= "ELECTRICITY COMPLAINT"
  department="ELECTRICITY DEPARTMENT"
  fee=200
  processing_time="1 DAY"
  status ="AVAILABLE"
  print()
def search_service():
  print("=====================================================================================================================================================================")
  print("                                                                       🔎 SEARCH SERVICE 🔎")
  print("=====================================================================================================================================================================")
  search_list=["ID CARD","VEHICLE PERMIT","WATER SERVICES","WATER PIPE LINES","WATER LEAKAGE","WIFI INSTALLATION","ELECTRICTY GENERATION","WASTE MANAGEMENT","BIRTH CERTIFICATE","ADDRESS CHANGE","APPLICATIONS"]
  print()
  list_res=[]
  search_list_inp=input("⌨️ ENTER WHAT YOU WANT TO SEARCH: ").upper()
  print()
  for x in search_list:
    if search_list_inp in x:
      list_res.append(x)
  if len(list_res)>0:
    print("AVAILABLE SERVICES ARE: ")
    print()
    for x in list_res:
      print(x)
    print()
  else:
    print("⛔ NO SERVICES AVAILABLE LIKE THIS ⛔")
    print()
  search_service_v=input("🔙 ENTER 1 TO GO BACK: ")
  print()
  if search_service_v=="1":
    citizen_government_services()
  else:
    print("‼️ INVALID OPTION TRY AGAIN ‼️")
    print()
    search_service()
  print()
#service ids and all conclusion-----------------------------------
#apply now beginning-----------------------------------------------
i=1
def apply_now():
  global app_id,status,i
  app_id="APP01"+str(i)
  status="SUBMITTED"
  i+=1
#apply now conclusion----------------------------------------------
#login beginning-----------------------------------------------
def citizen_login():
  global citizen_id_index
  print("===================================================================================================================================================================")
  print("                                                                      🏙️  CITIZEN LOGIN 🏙️ ")
  print("===================================================================================================================================================================")
  citizen_id_v=""
  citizen_pass_v=""
  print("\nPLEASE ENTER YOUR DETAILS HERE: ")
  print()
  citizen_id_v=input("🪪  CITIZEN ID:")
  citizen_id_v=citizen_id_v.lower()
  print()
  if citizen_id_v in details_id:
    citizen_pass_v=input("🔐 CITIZEN PASSWORD:")
    print()
    citizen_id_index=details_id.index(citizen_id_v)
    details_history[citizen_id_index].append("● CITIZEN LOGIN")
    if citizen_pass_v==details_pass[citizen_id_index]:
      print(" ✅ LOGIN SUCCESSFUL WELCOME "+details_name[citizen_id_index]+"! ✅")
      print()
      details_notifications[citizen_id_index].append("● YOU HAVE LOGGED IN NOW.")
      citizen_dashboard()
    else:
      print("‼️ INVALID PASSWORD ‼️")
      print()
      citizen_login()
  else:
    print("❗ THIS CITIZEN ID DOES NOT EXIST. TRY TO REGISTER. ❗ ")
    print()
    inp_log_in=input("1.OK✅ \n2.TRY AGAIN🔁 \n ⌨️ ENTER YOUR OPTION HERE(1-2):")
    if inp_log_in=="1":
      citizen_reg()
    elif inp_log_in=="2":
      citizen_login()
    else:
      print("‼️ INVALID OPTION TRY AGAIN‼️")
      print()
      citizen_login()
#login conclusion-----------------------------------------------------
#logout or exit-------------------------------------------------------
def log_out():
  print("=====================================================================================================================================================================")
  print("                                                                   🙏 THANK YOU🙏")
  print("                                                     🌆 SMART CITY IS ALWAYS AVAILABLE TO HELP YOU🌆")
  print("                                                                  🙏 VISIT AGAIN 🙏")
  print("=====================================================================================================================================================================")
  while True:
    break
#logout or exit--------------------------------------------------------
#bills beginning----------------------------------------------------
def bills():
  global citizen_id_index
  print("=====================================================================================================================================================================")
  print("                                                                       💲 BILLS 💲")
  print("=====================================================================================================================================================================")
  print()
  bill_inp=input("\n1.⌛  VIEW PENDING BILLS \n2.💸  VIEW PAID BILLS \n3.🔙  BACK \n ⌨️ TYPE YOUR OPTION HERE(1-3): ")
  details_history[citizen_id_index].append("● BILLS")
  print()
  if bill_inp=="1":
    def pending_bills():
      print("=====================================================================================================================================================================")
      print("                                                                   ⌛ PENDING BILLS ⌛")
      print("=====================================================================================================================================================================")
      print()
      if len(details_bills[citizen_id_index][0])!=0:
        print("YOUR PENDING BILLS ARE: ")
        print()
        for i in range(len(details_bills[citizen_id_index][0])):
          ind=i+1
          first=details_bills[citizen_id_index][0][i][0]
          last=details_bills[citizen_id_index][0][i][1]
          print(f"{ind}.{first}:{last}")
        print()
        pending_bill_v=input("1.🔙  BACK \n2.✔️  PAY NOW \n 🔙 TYPE YOUR OPTION HERE(1-2): ")
        print()
        if pending_bill_v=="1":
          bills()
        elif pending_bill_v=="2":
          print("CHOOSE YOUR PENDING BILLS TO PAY")
          print()
          for i in range(len(details_bills[citizen_id_index][0])):
            ind=i+1
            first=details_bills[citizen_id_index][0][i][0]
            last=details_bills[citizen_id_index][0][i][1]
            print(f"{ind}.{first}:{last}")
          print()
          print("ENTER THE OPTION BELOW(1-"+str(len(details_bills[citizen_id_index][0]))+")")
          bill_remove_v_1=input()
          print()
          if bill_remove_v_1.isdigit():
            if int(bill_remove_v_1)<=len(details_bills[citizen_id_index][0]) and int(bill_remove_v_1)>0:
              bill_remove_v=details_bills[citizen_id_index][0][int(bill_remove_v_1)-1]
              inp_pending_bill=input("DO YOU REALLY WANT TO PAY NOW? \n1.✅ YES \n2.❌ NO \nTYPE YOUR OPTION HERE: ")
              print()
              if inp_pending_bill=="1":
                if bill_remove_v in details_bills[citizen_id_index][0]:
                  print("✅ PAYMENT DONE SUCCESSFULLY✅")
                  removed_v=details_bills[citizen_id_index][0].pop(int(bill_remove_v_1)-1)
                  details_bills[citizen_id_index][1].append(removed_v)
                  print()
                  inp_remove_v=input("🔙  ENTER 1 TO GO BACK: ")
                  print()
                  if inp_remove_v=="1":
                    bills()
                  else:
                    print("‼️ INVALID OPTION TRY AGAIN ‼️")
                    print()
                    pending_bills()
                else:
                  print("⛔ THE AMOUNT IS NOT IN PENDING BILLS ⛔")
                  print()
                  pending_bills()
              elif inp_pending_bill=="2":
                print("😊 OKAY PAY THE BILL WHEN YOU ARE FREE 😊")
                print()
                inp_pending_bill_v=input("🔙  ENTER 1 TO GO BACK: ")
                print()
                if inp_pending_bill_v=="1":
                  bills()
                else:
                  print("‼️ INVALID OPTION TRY AGAIN ‼️")
                  print()
                  pending_bills()
            else:
              print("‼️ THERE IS NO PENDING BILL LIKE THAT.PLEASE ENTER A VALID OPTION ‼️")
              print()
              pending_bills()
          else:
            print("‼️ THERE IS NO PENDING BILL LIKE THAT.PLEASE ENTER A VALID OPTION ‼️")
            print()
            pending_bills()
      else:
        print("⛔ NO PENDING BILLS PRESENT HERE ⛔")
        print()
        inp_pending_bill_var=input("🔙 ENTER 1 TO GO BACK: ")
        if inp_pending_bill_var=="1":
          bills()
        else:
          print("‼️ INVALID OPTION TRY AGAIN ‼️")
          pending_bills()
    pending_bills()
  elif bill_inp=="2":
    def paid_bills():
      print("=====================================================================================================================================================================")
      print("                                                                    💸 PAID BILLS 💸 ")
      print("=====================================================================================================================================================================")
      print()
      if len(details_bills[citizen_id_index][1])!=0:
        for i in range(len(details_bills[citizen_id_index][1])):
          print((i+1),".",details_bills[citizen_id_index][1][i][0],":",details_bills[citizen_id_index][1][i][1])
        print()
        paid_bill_v=input("🔙  ENTER 1 TO GO BACK: ")
        print()
        if paid_bill_v=="1":
          bills()
        else:
          print("‼️ INVALID OPTION TRY AGAIN ‼️")
          print()
          paid_bills()
      else:
        print("⛔ THERE ARE NO PAID BILLS PRESENT HERE ⛔")
        print()
        inp_paid_bills=input("🔙 ENTER 1 TO GO BACK: ")
        if inp_paid_bills=="1":
          bills()
        else:
          print("‼️ INVALID OPTION TRY AGAIN ‼️")
          paid_bills()
    paid_bills()
  elif bill_inp=="3":
    citizen_dashboard()
  else:
    print("‼️ INVALID OPTION TRY AGAIN ‼️")
    print()
    bills()
#bills ending------------------------------------------------------
#explore services beginning----------------------------------------
def explore_services():
  print("=====================================================================================================================================================================")
  print("                                                                       🔎 EXPLORE SERVICES 🔎")
  print("=====================================================================================================================================================================")
  print()
  print("WE HAVE SO MANY GOVERNMENT SERVICES LIKE : \n\n● 🪪 NEW ID CARD \n● 🏡 ADDRESS CHANGE \n● 🚗 VEHICLE PERMITS \n● 📃 BIRTH CERTIFICATES \n● 💳 BUSINESS LICENSE \n● 🗑️ WASTE MANAGEMENT REQUEST \n● 💧 WATER CONNECTION \n● ⚡ ELECTRICITY COMPLAINT \n● 🔍 SEARCH SERVICE")
  print()
  print("TO GET TO KNOW ABOUT OUR SERVICES IN DETAIL PLEASE REGISTER (OR) LOGIN.")
  print()
  exp_inp=input("1.🆕  REGISTER \n2.💻  LOGIN \n3.🔙  BACK \nTYPE YOUR OPTION HERE(1-3): ")
  print()
  if exp_inp=="1":
    citizen_reg()
  elif exp_inp=="2":
    citizen_login()
  elif exp_inp=="3":
    start_decor()
    choose_opt()
  else:
    print("‼️ INVALID OPTION TRY AGAIN ‼️")
    print()
    explore_services()
#explaore services conclusion--------------------------------------
#my appliactions-----------------------------------------------
def my_apps():
  global app_id,citizen_id_index
  print("===================================================================================================================================================================")
  print("                                                                           📄 MY APPLICATIONS📄")
  print("===================================================================================================================================================================")
  print()
  if details_applications[citizen_id_index]:
    print("YOUR APPLICATIONS ARE: ")
    print()
    for x in details_applications[citizen_id_index]:
      print("●",x)
    print()
    app_id_inp=input("1.🔙  BACK \n2.📄  APPLICATION DETAILS \n\nENTER YOUR CHOICE HERE(1-2): ")
    print()
    if app_id_inp=="2":
      print("===================================================================================================================================================================")
      print("                                                                           📄 APPLICATION DETAILS📄")
      print("===================================================================================================================================================================")
      app_id=input("⌨️  TYPE YOUR APPLICATION ID HERE FOR MORE DETAILS : ")
      print()
      if app_id in details_applications[citizen_id_index]:
        for p,q in applications[app_id].items():
          print(p,q)
        print()
      else:
        print("‼️ THERE IS NO APPLICATION LIKE THIS TRY AGAIN ‼️")
        print()
        my_apps()
    elif app_id_inp=="1":
      citizen_dashboard()
    else:
      print("‼️ INVALID OPTION TRY AGAIN ‼️")
      my_apps()
  else:
    print("🚫 NO APPLICATION IS CREATED YET 🚫")
    print()
  app_v=input("🔙  ENTER 1 TO GO BACK: ")
  print()
  if app_v=="1":
    citizen_dashboard()
  else:
    print("‼️ INVALID OPTION TRY AGAIN ‼️")
    print()
    my_apps()
#my applications--------------------------------------------------
def choose_opt():
  menu_opt=input("\n ⌨️   ENTER YOUR OPTION HERE(1-5):")
  print()
  if menu_opt.isdigit()==True:
    match menu_opt:
        case "1":
            citizen_login()    
        case "2":
            citizen_reg()
        case "3":
            explore_services()
        case "4":
            def help():
              print("===================================================================================================================================================================")
              print("\n                                                                        🚨  HELP  🚨")
              print("===================================================================================================================================================================")
              print()
              print("                                                         😊 FOR FURTHER INFORMATION CONTACT 7842546869 😊")
              print()
              help_inp=input("🔙  ENTER 1 TO GO BACK: ")
              print()
              if help_inp=="1":
                start_decor()
                choose_opt()
              else:
                print("‼️ INVALID OPTION TRY AGAIN ‼️")
                help()
            help()
        case "5":
            def exit():
              exit_inp=input("DO YOU REALLY WANT TO EXIT? \n\n1.✅ YES \n2.❌ NO \nTYPE YOUR OPTION HERE(1-2): ")
              print()
              if exit_inp=="1":
                log_out()
              elif exit_inp=="2":
                choose_opt()
              else:
                print("‼️ INVALID OPTION TRY AGAIN ‼️")
                print()
                exit()
            exit()
        case _:
            print("‼️ INVALID OPTION TRY AGAIN ‼️")
            print()
            choose_opt()
  else:
    print("‼️ INVALID OPTION TRY AGAIN ‼️")
    print()
    choose_opt()
choose_opt()